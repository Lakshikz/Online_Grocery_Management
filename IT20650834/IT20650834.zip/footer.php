  
  <!-- Footer -->
  <footer class="w3-container w3-padding-32 w3-grey">  
    <div class="w3-row-padding">
      <div class="w3-third">
      <h3> INFO</h3>
        <h6><i class="fa fa-fw fa-map-marker"></i> Fresh Mart Srilanka</h6>
        <h6><i class="fa fa-fw fa-phone"></i> 0115 237 345</h6>
        <h6><i class="fa fa-fw fa-envelope"></i> freshmart@gmail.com</h6>
		<h6><i class="fa fa-fw fa-fax"></i> +94-208-1234567</h6>
		<h6><i class="fa fa-fw fa-globe"></i> www.freshmart.com</h6>
		

	  
		
		
    </div>
    
          <div class="w3-third">

      <div class="w3-third">
      <h3> HELP</h3>
        <h6><a target="_blank" href="sample.html">FAQs</a></h6>
        <h6><a target="_blank" href="sample.html">Contact Us</a></h6>
		<h6><a target="_blank" href="sample.html">About Us</a></h6>
		<h6><a target="_blank" href="sample.html">Pravacy Policy</a></h6>
		<h6><a target="_blank" href="sample.html">Terms&Conditions</a></h6>
		
		
    </div>
    </div>

    <div class="w3-third w3-serif">
      <h3>POPULAR TAGS</h3>
      <p>
        <span class="w3-tag w3-black w3-margin-bottom">Vegetables</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Fruits</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Apple</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Salmon</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Foods</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Drinks</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Fish</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Flavors</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Milk</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Chicken</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Meat</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Buiscuit</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Grapes</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Honey</span>
      </p>
	  
	  			  
	  	<i class="fa fa-facebook-official w3-hover-opacity w3-large"></i>
        <i class="fa fa-instagram w3-hover-opacity w3-large"></i>
        <i class="fa fa-snapchat w3-hover-opacity w3-large"></i>
        <i class="fa fa-pinterest-p w3-hover-opacity w3-large"></i>
        <i class="fa fa-twitter w3-hover-opacity w3-large"></i>
        <i class="fa fa-linkedin w3-hover-opacity w3-large"></i>
	  

    </div>

  </footer>
  
<!-- CopyRight bar-->
  <div class="w3-black w3-center w3-padding-24">© 2021 Copyright: <a href="freshmart.com" title="freshmart.com" target="_blank" class="w3-hover-opacity">www.freshmart.com</a></div>
