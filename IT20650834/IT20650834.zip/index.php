<!DOCTYPE html>
<html>
<title>Fresh Mart</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
.w3-bar-block .w3-bar-item {padding:20px}

* {box-sizing: border-box;}

body { 
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.header {
  overflow: hidden;
  background-color: #f1f1f1;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

.header a:hover {
  background-color: #ddd;
  color: black;
}

.header a.active {
  background-color: dodgerblue;
  color: white;
  border : solid;
  padding : 8px;
}

.header-right {
  float: right;
}

@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .header-right {
    float: none;
  }
}


.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 18px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #006400;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}


#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 40px;
  z-index: 99;
  font-size: 15px;
  border: none;
  outline: none;
  background-color: #C0C0C0;
  color: black;
  cursor: pointer;
  padding: 10px;
  border-radius: 8px;
}

#myBtn:hover {
  background-color: #555;
}



.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 18px;  
  border: none;
  outline: none;
  color: black;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: transparent;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

* {box-sizing: border-box;}
body {font-family: Verdana, sans-serif;}
.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 0px;
  width: 0px;
  margin: 0 2px;
  background-color: transparent;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}

div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}

</style>
<body>


<!--Header-->
<div class="header">

  <a href="Register.php" class="logo">
  <img src="images/logo.jpg"
			class="img-fluid" alt="Responsive image" width="50px" height="50px">
			  Fresh Mart</a>
  <div class="header-right">
	
	</a>
    <a href="index.php" class="w3-bar-item w3-button" ><i class="fa fa-home"></i> HOME</a>
    <a href="#about" class="w3-bar-item w3-button w3-hide-small"><i class="fa fa-user"></i> ABOUT</a>
    <a href="displayUser.php" class="w3-bar-item w3-button w3-hide-small"><i class="fa fa-th"></i> Admin Profile</a>
    <a href="#contact" class="w3-bar-item w3-button w3-hide-small"><i class="fa fa-envelope"></i> CONTACT</a>


<div class="dropdown">

    <button class="dropbtn"><i class="fa fa-bars"></i> CATEGORY 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Fish & Meat</a>
      <a href="#">Fruit & Vegetables </a>
      <a href="#">Frozen Foods</a>
	  <a href="#">Dairy Egg & Chilled Products</a>
	  <a href="#">Baby & Toddler</a>
	  <a href="#">Bakery</a>
	  <a href="#">Household & Home Care</a>
	  <a href="#">Convenience Food</a>
	  <a href="#">Dry Rations</a>
	  <a href="#">Jams & Spreads</a>
    </div>
  </div> 

	<a class="active" href="Login.php" class="w3-bar-item w3-button w3-hide-small"><i style="font-size:20px;" class="fa fa-sign-in"></i> Sign In</a>
	<a class="active" href="Register.php" class="w3-bar-item w3-button w3-hide-small"><i style="font-size:20px;" class="fa fa-registered"></i> Register </a>

    <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-hover-red">
      <i class="fa fa-search"></i>
    </a>
	
	
  </div>
</div>
<!--Header End-->


<!-- !PAGE CONTENT! -->
<div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:40px">

<h4 align="center"><b>Shop by Category</b></h4>





  <!-- First Photo Grid-->
  <div class="w3-row-padding w3-padding-16 w3-center" id="food">
  
    <div class="w3-quarter">
      <div class="card">
  <img src="images/capsicum.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Capsicum</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
	
	
    <div class="w3-quarter">
<div class="card">
  <img src="images/carrot.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Carrot</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
	
	
    <div class="w3-quarter">
      <div class="card">
  <img src="images/lemon.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Lemon</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
 
    </div>
	
	
    <div class="w3-quarter">
      <div class="card">
  <img src="images/beans.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Beans</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
	
  </div>
  
  <!-- Second Photo Grid-->
  <div class="w3-row-padding w3-padding-16 w3-center">
  
    <div class="w3-quarter">
      <div class="card">
  <img src="images/water.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Water Melon</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
	
	<div class="w3-quarter">
      <div class="card">
  <img src="images/mango.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Mango</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
	
    <div class="w3-quarter">
      <div class="card">
  <img src="images/cucumber.jpeg" alt="Denim Jeans" style="width:100%">
  <h3>Cucumber</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
    
    <div class="w3-quarter">
      <div class="card">
  <img src="images/grapes.jpg" alt="Denim Jeans" style="width:100%">
  <h3>Grapes</h3>
  <p class="price">$19.99</p>
  <p><button>Add to Cart</button></p>
</div>
    </div>
  </div>




  <!-- About Section -->
  <div class="w3-container w3-padding-32 w3-center">  
    <h3>Featured Recipes Fresh Mart</h3><br>

	<!--Image Slide Show-->
	<div class="slideshow-container">

<div class="mySlides fade">
  <img src="images/main.png" style="width:100%">
</div>

<div class="mySlides fade">
  <img src="images/main2.jpg" style="width:100%">
</div>

<div class="mySlides fade">
  <img src="images/main3.jpg" style="width:100%">
</div>

</div>
<br>
<!--Sliding Images using JS-->
<div style="text-align:center">
  <span class= "dot"></span> 
  <span class= "dot"></span> 
  <span class= "dot"></span> 
</div>

	<!--Intro-->
    <div class="w3-padding-32">
      <h4><b>Who we are!</b></h4>
      <h6><i><b>Fresh Mart – Online Grocery Store</b></i></h6>
      <h6>Did you ever imagine that the freshest of fruits and vegetables, top quality pulses and food grains, dairy products 
	  and hundreds of branded items could be handpicked and delivered to your home, all at the click of a button? India’s first comprehensive online megastore, bigbasket.com, brings a whopping 20000+ products with more than 1000 brands, 
	  to over 4 million happy customers. From household cleaning products to beauty and makeup, bigbasket has everything you need 
	  for your daily needs. bigbasket.com is convenience personified We’ve taken away all the stress associated with shopping for daily essentials, and you can now order all your household products and even buy groceries online without travelling 
	  long distances or standing in serpentine queues. </h6>
    </div>
  
  <hr>
  <br>
  
  <!--Image Gallery 'Navigate to Functions'-->
  <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
    <img src="images/discount.jpg" alt="Deals & Discount" width="600" height="400">
  </a>
  <div class="desc"><b>Deals & Discount</b></div>
</div>

<div class="gallery">
  <a target="_blank" href="img_forest.jpg">
    <img src="images/payment.png" alt="Payment" width="600" height="400">
  </a>
  <div class="desc"><b>Payment</b></div>
</div>

<div class="gallery">
  <a target="_blank" href="img_lights.jpg">
    <img src="images/deliver.jpg" alt="Delivery" width="600" height="400">
  </a>
  <div class="desc"><b>Delivery</b></div>
</div>

<div class="gallery">
  <a target="_blank" href="img_mountains.jpg">
    <img src="images/offer.jpg" alt="Offers" width="600" height="400">
  </a>
  <div class="desc"><b>Offers</b></div>
</div>
  
  
<div class="gallery">
  <a target="_blank" href="img_mountains.jpg">
    <img src="images/notice.jpg" alt="Notice" width="600" height="400">
  </a>
  <div class="desc"><b>Special Notices</b></div>
</div> 
 
  
  </div>
 
 <!-- Button to view Top -->
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>

<!-- End page content -->
</div>


  <!-- Footer -->
  <footer class="w3-container w3-padding-32 w3-grey">  
    <div class="w3-row-padding">
      <div class="w3-third">
      <h3> INFO</h3>
        <h6><i class="fa fa-fw fa-map-marker"></i> Fresh Mart Srilanka</h6>
        <h6><i class="fa fa-fw fa-phone"></i> 0115 237 345</h6>
        <h6><i class="fa fa-fw fa-envelope"></i> freshmart@gmail.com</h6>
		<h6><i class="fa fa-fw fa-fax"></i> +94-208-1234567</h6>
		<h6><i class="fa fa-fw fa-globe"></i> www.freshmart.com</h6>
		

	  
		
		
    </div>
    
          <div class="w3-third">

      <div class="w3-third">
      <h3> HELP</h3>
        <h6><a target="_blank" href="sample.html">FAQs</a></h6>
        <h6><a target="_blank" href="sample.html">Contact Us</a></h6>
		<h6><a target="_blank" href="sample.html">About Us</a></h6>
		<h6><a target="_blank" href="sample.html">Pravacy Policy</a></h6>
		<h6><a target="_blank" href="sample.html">Terms&Conditions</a></h6>
		
		
    </div>
    </div>

    <div class="w3-third w3-serif">
      <h3>POPULAR TAGS</h3>
      <p>
        <span class="w3-tag w3-black w3-margin-bottom">Vegetables</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Fruits</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Apple</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Salmon</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Foods</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Drinks</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Fish</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Flavors</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Milk</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Chicken</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Meat</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Buiscuit</span>
        <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Grapes</span> <span class="w3-tag w3-dark-grey w3-small w3-margin-bottom">Honey</span>
      </p>
	  
	  			  
	  	<i class="fa fa-facebook-official w3-hover-opacity w3-large"></i>
        <i class="fa fa-instagram w3-hover-opacity w3-large"></i>
        <i class="fa fa-snapchat w3-hover-opacity w3-large"></i>
        <i class="fa fa-pinterest-p w3-hover-opacity w3-large"></i>
        <i class="fa fa-twitter w3-hover-opacity w3-large"></i>
        <i class="fa fa-linkedin w3-hover-opacity w3-large"></i>
	  

    </div>

  </footer>
  
<!-- CopyRight bar-->
  <div class="w3-black w3-center w3-padding-24">© 2021 Copyright: <a href="freshmart.com" title="freshmart.com" target="_blank" class="w3-hover-opacity">www.freshmart.com</a></div>


<script>
//Get the button
var mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}


var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 3000); // Change image every 3 seconds
}


</script>

</body>
</html>
